package gameChart;

public class Hill extends Box {

}
