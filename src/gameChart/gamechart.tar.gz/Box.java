package gameChart;

public abstract class Box {
	
	public Box() {};
	
}
