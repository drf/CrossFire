package gameChart;

import java.util.Set;

public class CircolarChart extends AbstractChart {

	public CircolarChart() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Set<Box> getAdjacentBoxes(Box b) {
		// TODO Auto-generated method stub
		return null;
	}

}
