package gameChart;

public class Plain extends Box {

}
