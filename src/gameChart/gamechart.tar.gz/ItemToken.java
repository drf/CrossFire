package gameChart;

import items.Item;

public class ItemToken extends Token {

	private Item i;

	public ItemToken(Item i) {
		this.i = i;
	}

	public Item get() {
		return this.i;
	}
}	
