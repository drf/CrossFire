package gameChart;

public class ChartController {
	private Chart chart;
	
	public ChartController(Chart chart) {
		this.chart = chart;
	}
	
	public void move(Character c, Box b) {
		
	}

}
