package gameChart;

import characters.Character;

public class CharacterToken extends Token {

	private Character c;
	
	public CharacterToken(Character c){
		this.c = c;
	}
	
	public Character get(){
		return this.c;
	}	
}
