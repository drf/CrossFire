package gameChart;

public class City extends Box {

}
